from flask import Flask, flash, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


# Creating an instance of flask
app = Flask(__name__)

# Add a database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'

# Secret Key
app.config['SECRET_KEY'] = "secret key"

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initiate a Database
db = SQLAlchemy(app)


# Creating a sample Namer form
class NamerForm(FlaskForm):
    name = StringField("Name please:", validators=[DataRequired()])
    submit = SubmitField("Submit")

## Creating necessary models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    age = db.Column(db.String(255))
    email = db.Column(db.String(255), unique=True, nullable=False)
    phone_no = db.Column(db.String(255))
    date_added = db.Column(db.Date, default=datetime.utcnow)
    orders = db.relationship('Order', backref = 'user')

    def __repr__(self):
        return f'<id : {self.id}, Name : {self.name}, Email: {self.email}>'


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'))
    payment_status = db.Column(db.String(255))
    date_added = db.Column(db.Date, default=datetime.utcnow)

    def __repr__(self):
        return f'<id : {self.id}, book_id : {self.book_id}, user_id : {self.user_id}>'

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    year_of_publish = db.Column(db.String(255))
    book_available = db.Column(db.String(255))
    date_added = db.Column(db.Date, default=datetime.utcnow)
    orders = db.relationship('Order', backref = 'book')

    def __repr__(self):
        return f'<id : {self.id}, name : {self.name}, available : {self.book_available}>'


# Create a User Form Class
class UserForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    age = StringField("Age", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired()])
    phone_no = StringField("Phone_No", validators=[DataRequired()])
    submit = SubmitField("Submit")


# Create a Book Form Class
class BookForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    year_of_publish = StringField("Year Of Publishing", validators=[DataRequired()])
    book_available = StringField("Book Available", validators=[DataRequired()])
    submit = SubmitField("Submit")

# Create a Order Form Class
class OrderForm(FlaskForm):
    user_id = StringField("User ID", validators=[DataRequired()])
    book_id = StringField("Book ID", validators=[DataRequired()])
    payment_status = StringField("Payment Status", validators=[DataRequired()])
    submit = SubmitField("Submit")


#### Sample data
# niranjan = User(name = 'niranjan', age = '35', email = 'niranjan@gmail.com', phone_no = '8349671295')
# raju = User(name = 'raju', age = '29', email = 'raju@yahoo.com', phone_no = '9437271738')
# rahul = User(name = 'rahul', age = '38', email = 'rahulrocks@gmail.com', phone_no = '6215662277')
# rohit = User(name = 'rohit', age = '21', email = 'rohitbooks@gmail.com', phone_no = '8877662231')
# priya = User(name = 'priya', age = '23', email = 'priyabookreader@gmail.com', phone_no = '6345821166')

# harry_potter = Book(name = 'harry potter', year_of_publish = '1987', book_available = 'yes')
# percy_jacskon = Book(name = 'percy jackson', year_of_publish = '1925', book_available = 'yes')
# hercules = Book(name = 'hercules', year_of_publish = '1878', book_available = 'yes')
# ankit_batra = Book(name = 'batra tablets', year_of_publish = '1929', book_available = 'yes')
# sp_jain = Book(name = 'maths_sp', year_of_publish = '1498', book_available = 'yes')



###### Front end

@app.route('/')
def Index():
    return render_template("index.html")

@app.route('/table/<name>')
def table(name):
    return render_template("table.html", name=name)

@app.route('/name', methods = ['GET', 'POST'])
def name():
    name = None
    form = NamerForm()
    # Validate Form
    if form.validate_on_submit():
        name = form.name.data
        form.name.data = ''
        flash("Form submitted successfully!")

    return render_template("name.html", name=name, form=form)


### Invalid URL
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

### Internal Server Error
@app.errorhandler(500)
def page_not_found(e):
    return render_template("500.html"), 500

@app.route('/user/add', methods=['GET', 'POST'])
def add_user():
    name = None
    age = None
    email = None
    phone_no = None
    form = UserForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user is None:
            user = User(name=form.name.data, age=form.age.data, email=form.email.data, phone_no=form.phone_no.data)
            db.session.add(user)
            db.session.commit()
        name = form.name.data
        age = form.age.data
        email = form.email.data
        phone_no = form.phone_no.data
        form.name.data = ''
        form.email.data = ''
        form.age.data = ''
        form.phone_no.data = ''
        flash("User added successfully")
    our_users = User.query.order_by(User.date_added)
    
    return render_template('add_user.html', form=form, name=name, age=age, email=email, phone_no=phone_no, our_users=our_users)


@app.route('/book/add', methods=['GET', 'POST'])
def add_book():
    name = None
    year_of_publish = None
    book_available = None
    form = BookForm()
    if form.validate_on_submit():
        book = Book.query.filter_by(name=form.name.data).first()
        if book is None:
            book = Book(name=form.name.data, year_of_publish=form.year_of_publish.data, book_available=form.book_available.data)
            db.session.add(book)
            db.session.commit()
        name = form.name.data
        year_of_publish = form.year_of_publish.data
        book_available = form.book_available.data
        form.year_of_publish.data = ''
        form.book_available.data = ''
        form.name.data = ''
        flash("Book added successfully")
    our_books = Book.query.order_by(Book.date_added)
    
    return render_template('add_book.html', form=form, name=name, year_of_publish=year_of_publish, book_available=book_available, our_books=our_books)


@app.route('/order/add', methods=['GET', 'POST'])
def add_order():
    user_id = None
    book_id = None
    payment_status = None
    form = OrderForm()
    if form.validate_on_submit():
        if (form.user_id.data is not None and form.book_id.data is not None):
            order = Order(user_id=form.user_id.data, book_id=form.book_id.data, payment_status=form.payment_status.data)
            db.session.add(order)
            db.session.commit()
        user_id=form.user_id.data
        book_id=form.book_id.data
        payment_status=form.payment_status.data
        form.user_id.data = ''
        form.book_id.data = ''
        form.payment_status.data = ''
        flash("Order added successfully")
    our_orders = Order.query.order_by(Order.date_added)
    
    return render_template('add_order.html', form=form, user_id=user_id, book_id=book_id , payment_status=payment_status, our_orders=our_orders)
